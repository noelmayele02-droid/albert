import { Brain, Linkedin, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import neurobusLogo from "/lovable-uploads/2534aa65-250c-49bc-8848-13f54f654aef.png";
import QRCode from "react-qr-code";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-secondary/20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-5 gap-8 text-center">
          <div className="space-y-4">
            <div className="flex items-center justify-center space-x-3">
              <img 
                src={neurobusLogo} 
                alt="Neurobus Logo" 
                className="h-6 w-auto"
              />
            </div>
            <p className="text-muted-foreground text-sm">
              Neuromorphic intelligence for autonomous systems<br />
              inspired by the human biology, built for the edge.
            </p>
            
            {/* Company LinkedIn */}
            <div className="flex justify-center">
              <Button 
                variant="ghost" 
                size="sm"
                className="text-muted-foreground hover:text-accent hover:bg-accent/10 transition-all duration-300"
                asChild
              >
                <a 
                  href="https://www.linkedin.com/company/neurobus/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <Linkedin className="h-4 w-4" />
                  <span className="text-sm">Follow us on LinkedIn</span>
                </a>
              </Button>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Solutions</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#solutions" className="hover:text-foreground transition-colors">Ground Station</a></li>
              <li><a href="#solutions" className="hover:text-foreground transition-colors">Drones</a></li>
              <li><a href="#solutions" className="hover:text-foreground transition-colors">Satellites</a></li>
              <li><a href="#solutions" className="hover:text-foreground transition-colors">OS</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#about" className="hover:text-foreground transition-colors">About us</a></li>
              <li><a href="#news" className="hover:text-foreground transition-colors">News</a></li>
              <li><a href="#careers" className="hover:text-foreground transition-colors">Careers</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center justify-center gap-2">
                <Mail className="h-4 w-4 text-accent" />
                <a href="mailto:infotelcomtech@gmail.com" className="hover:text-foreground transition-colors">
                  infotelcomtech@gmail.com
                </a>
              </li>
              <li className="flex items-center justify-center gap-2">
                <Phone className="h-4 w-4 text-accent" />
                <a href="tel:+242068498792" className="hover:text-foreground transition-colors">
                  +242 068498792
                </a>
              </li>
              <li className="flex items-center justify-center gap-2">
                <Phone className="h-4 w-4 text-accent" />
                <a href="tel:+33652861159" className="hover:text-foreground transition-colors">
                  +33 652861159
                </a>
              </li>
            </ul>
          </div>

          <div className="flex flex-col items-center">
            <h4 className="font-semibold mb-4">Scannez pour visiter</h4>
            <div className="bg-white p-3 rounded-lg">
              <QRCode 
                value="https://neurobu-launchpad.lovable.app/" 
                size={120}
                level="H"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Scannez le QR code</p>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 flex flex-col items-center justify-center text-center space-y-3">
          <p className="text-sm text-muted-foreground">
            © 2025 Neurobus. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground/80">
            Créé par <span className="text-accent font-medium">Mayele Albert</span> alias <span className="text-accent font-medium">Monsieur Z Anonymous</span>, dirigeant de <span className="font-medium">Infotelcom</span>
          </p>
          <div className="flex space-x-6 mt-4">
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;