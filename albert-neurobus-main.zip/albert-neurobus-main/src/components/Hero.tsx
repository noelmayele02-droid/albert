import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";
import BackgroundEffects from "./hero/BackgroundEffects";
import FloatingParticles from "./hero/FloatingParticles";

const Hero = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Trigger animations after component mounts
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Dynamic Background */}
      <BackgroundEffects />
      
      {/* Floating particles */}
      <FloatingParticles />
      
      {/* Content */}
      <div className={`container mx-auto px-8 z-20 text-center max-w-7xl transition-all duration-1000 ${
        isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}>
        <div className="max-w-5xl mx-auto space-y-12">
          <div className="space-y-8">
            <h1 className="text-6xl md:text-8xl lg:text-9xl font-normal tracking-tight leading-none text-white">
              BUILDING
              <br />
              <span className="text-accent animate-pulse">TOMORROW'S</span>
              <br />
              AUTONOMY
            </h1>
            
            <p className="text-xl md:text-2xl text-white max-w-4xl mx-auto font-light leading-relaxed drop-shadow-lg [text-shadow:2px_2px_4px_rgba(0,0,0,0.8)]">
              Autonomous platforms engineered for the most demanding environments.
            </p>
          </div>
          
          <div className="flex justify-center items-center gap-8 pt-8">
            <Button 
              variant="hero" 
              size="xl" 
              className="relative overflow-hidden group px-12 py-5 text-lg font-semibold tracking-wider border-0 shadow-2xl"
              asChild
            >
              <a href="https://calendly.com/florian-neurobus/30min" target="_blank" rel="noopener noreferrer">
                <span className="relative z-10 flex items-center">
                  SCHEDULE MEETING
                  <ArrowRight className="ml-3 h-5 w-5 group-hover:translate-x-2 transition-transform duration-300" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/5 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </a>
            </Button>
          </div>
        </div>
      </div>
      
      {/* Status indicators */}
      <div className={`absolute bottom-12 left-8 z-20 flex flex-col space-y-4 text-sm text-gray-400 font-light transition-all duration-1000 delay-300 ${
        isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
      }`}>
        <div className="flex items-center space-x-3 group hover:text-accent transition-colors">
          <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
          <span className="tracking-wide">AUTONOMOUS SYSTEMS</span>
        </div>
        <div className="flex items-center space-x-3 group hover:text-accent transition-colors">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
          <span className="tracking-wide">NEUROMORPHIC AI</span>
        </div>
        <div className="flex items-center space-x-3 group hover:text-accent transition-colors">
          <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
          <span className="tracking-wide">EDGE COMPUTING</span>
        </div>
      </div>

      {/* Industry indicators */}
      <div className={`absolute bottom-12 right-8 z-20 flex flex-col space-y-2 text-xs text-gray-500 font-light transition-all duration-1000 delay-500 ${
        isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
      }`}>
        <div className="tracking-wider hover:text-accent transition-colors cursor-default">DRONES</div>
        <div className="tracking-wider hover:text-accent transition-colors cursor-default">AERONAUTICS</div>
        <div className="tracking-wider hover:text-accent transition-colors cursor-default">AEROSPACE</div>
        <div className="tracking-wider hover:text-accent transition-colors cursor-default">DEFENSE</div>
      </div>

      {/* Enhanced scan line effects */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent to-transparent animate-scan z-25" />
      <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent animate-scan z-25" style={{animationDelay: '4s'}} />
    </section>
  );
};

export default Hero;