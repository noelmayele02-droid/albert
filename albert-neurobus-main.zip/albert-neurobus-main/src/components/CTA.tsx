import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-16 relative overflow-hidden">
      {/* Advanced gradient background */}
      <div className="absolute inset-0 bg-gradient-section" />
      <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-accent/10" />
      
      {/* Enhanced Neuromorphic Network Background */}
      <div className="absolute inset-0 opacity-30">
        {/* Multi-layered neural grid */}
        <div className="absolute inset-0" style={{
          backgroundImage: `
            radial-gradient(circle at 15% 25%, hsl(220 100% 60% / 0.15) 2px, transparent 2px),
            radial-gradient(circle at 85% 25%, hsl(240 100% 70% / 0.12) 1.5px, transparent 1.5px),
            radial-gradient(circle at 45% 45%, hsl(280 100% 50% / 0.1) 2.5px, transparent 2.5px),
            radial-gradient(circle at 65% 65%, hsl(220 100% 60% / 0.13) 1px, transparent 1px),
            radial-gradient(circle at 25% 75%, hsl(200 100% 60% / 0.11) 2px, transparent 2px),
            radial-gradient(circle at 75% 85%, hsl(260 100% 60% / 0.14) 1.5px, transparent 1.5px)
          `,
          backgroundSize: '250px 250px, 300px 300px, 350px 350px, 200px 200px, 280px 280px, 320px 320px'
        }} />
        
        {/* Advanced synaptic connections */}
        <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="neuralGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="hsl(220 100% 60% / 0.4)" />
              <stop offset="50%" stopColor="hsl(240 100% 70% / 0.3)" />
              <stop offset="100%" stopColor="hsl(280 100% 50% / 0.4)" />
            </linearGradient>
            <linearGradient id="neuralGradient2" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="hsl(200 100% 60% / 0.3)" />
              <stop offset="100%" stopColor="hsl(260 100% 60% / 0.3)" />
            </linearGradient>
            <filter id="neuralGlow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge> 
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          
          {/* Complex neural pathways */}
          <g filter="url(#neuralGlow)">
            <path d="M 80 120 Q 250 180 420 140 T 680 160" stroke="url(#neuralGradient1)" strokeWidth="1.5" fill="none" opacity="0.7">
              <animate attributeName="stroke-dasharray" values="0,2000;100,1900;200,1800;300,1700" dur="12s" repeatCount="indefinite" />
            </path>
            <path d="M 150 280 Q 350 120 550 250 T 750 200" stroke="url(#neuralGradient2)" strokeWidth="1" fill="none" opacity="0.5">
              <animate attributeName="stroke-dasharray" values="0,2000;80,1920;160,1840;240,1760" dur="10s" repeatCount="indefinite" />
            </path>
            <path d="M 50 200 Q 200 80 350 180 Q 500 280 650 150" stroke="url(#neuralGradient1)" strokeWidth="1.2" fill="none" opacity="0.6">
              <animate attributeName="stroke-dasharray" values="0,2000;120,1880;240,1760;360,1640" dur="14s" repeatCount="indefinite" />
            </path>
            <path d="M 250 60 Q 450 280 650 120 T 850 180" stroke="url(#neuralGradient2)" strokeWidth="0.8" fill="none" opacity="0.4">
              <animate attributeName="stroke-dasharray" values="0,2000;60,1940;120,1880;180,1820" dur="8s" repeatCount="indefinite" />
            </path>
          </g>
          
          {/* Enhanced neural nodes with pulsing effect */}
          <g>
            <circle cx="80" cy="120" r="4" fill="hsl(220 100% 60% / 0.5)">
              <animate attributeName="r" values="3;6;3" dur="4s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.3;0.8;0.3" dur="4s" repeatCount="indefinite" />
            </circle>
            <circle cx="420" cy="140" r="3" fill="hsl(240 100% 70% / 0.4)">
              <animate attributeName="r" values="2;5;2" dur="5s" repeatCount="indefinite" />
            </circle>
            <circle cx="150" cy="280" r="5" fill="hsl(280 100% 50% / 0.6)">
              <animate attributeName="r" values="4;7;4" dur="3s" repeatCount="indefinite" />
            </circle>
            <circle cx="550" cy="250" r="3" fill="hsl(200 100% 60% / 0.4)">
              <animate attributeName="r" values="2;5;2" dur="6s" repeatCount="indefinite" />
            </circle>
            <circle cx="650" cy="150" r="4" fill="hsl(260 100% 60% / 0.5)">
              <animate attributeName="r" values="3;6;3" dur="4.5s" repeatCount="indefinite" />
            </circle>
          </g>
        </svg>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-5xl mx-auto text-center space-y-10">
          {/* Enhanced badge */}
          <div className="inline-flex items-center px-6 py-3 rounded-full bg-gradient-tech border border-accent/30 mb-8 animate-pulse-glow">
            <Sparkles className="h-5 w-5 text-accent mr-3 animate-pulse" />
            <span className="text-sm text-accent font-semibold tracking-wide">Ready to Deploy Neuromorphic Intelligence?</span>
          </div>
          
          {/* Main CTA heading with enhanced typography */}
          <div className="relative">
            <h2 className="text-4xl md:text-6xl font-semibold leading-tight tracking-normal mb-6 transform rotate-1">
              <span className="text-foreground">Partner with</span>
              <span className="bg-gradient-neural bg-clip-text text-transparent block mt-2">
                Neurobus Today
              </span>
            </h2>
            {/* Decorative elements */}
            <div className="absolute -top-8 -left-8 w-16 h-16 border border-accent/20 rotate-45 animate-quantum-float" />
            <div className="absolute -bottom-8 -right-8 w-12 h-12 bg-accent/10 rotate-12 animate-quantum-float" style={{animationDelay: '2s'}} />
          </div>
          
          {/* Enhanced description */}
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Transform your autonomous systems with cutting-edge neuromorphic computing. 
            Join industry leaders who trust Neurobus for mission-critical AI solutions.
          </p>
          
          {/* Enhanced CTA button */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 pt-12">
            <div className="relative group">
              <Button 
                variant="neural" 
                size="xl" 
                className="relative overflow-hidden px-16 py-6 text-xl font-bold tracking-wider shadow-2xl" 
                asChild
              >
                <a href="https://calendly.com/florian-neurobus/30min" target="_blank" rel="noopener noreferrer">
                  <span className="relative z-10 flex items-center">
                    Schedule Meeting
                    <ArrowRight className="h-6 w-6 ml-3 group-hover:translate-x-3 transition-transform duration-400" />
                  </span>
                  {/* Enhanced button glow effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/10 to-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-600" />
                  <div className="absolute -inset-1 bg-gradient-neural opacity-30 blur-lg group-hover:opacity-60 transition-opacity duration-600" />
                </a>
              </Button>
            </div>
          </div>
          
        </div>
      </div>
      
      {/* Enhanced floating neural elements */}
      <div className="absolute top-1/6 left-12 w-8 h-8 bg-accent/20 rounded-full animate-quantum-float">
        <div className="absolute inset-2 bg-accent/40 rounded-full animate-pulse" />
      </div>
      <div className="absolute top-1/2 right-12 w-6 h-6 border-2 border-accent/30 rounded-full animate-quantum-float" style={{animationDelay: '1s'}} />
      <div className="absolute bottom-1/4 left-1/2 w-10 h-10 bg-gradient-to-br from-accent/10 to-accent/20 rounded-full animate-quantum-float" style={{animationDelay: '2s'}} />
      <div className="absolute top-1/3 right-1/6 w-4 h-4 bg-accent/25 rounded-full animate-neural-pulse" />
      <div className="absolute bottom-1/3 left-1/6 w-7 h-7 border border-accent/20 rotate-45 animate-quantum-float" style={{animationDelay: '3s'}} />
      <div className="absolute top-2/3 right-1/4 w-5 h-5 bg-accent/15 rounded-full animate-neural-pulse" style={{animationDelay: '1.5s'}} />
    </section>
  );
};

export default CTA;