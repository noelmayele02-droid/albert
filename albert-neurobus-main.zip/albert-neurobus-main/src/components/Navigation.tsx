import { Button } from "@/components/ui/button";
import { Linkedin, Menu, X } from "lucide-react";
import { useState } from "react";
import neurobusLogo from "/lovable-uploads/3d25a76c-7f7d-4917-858b-57376c63d9dd.png";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navigationItems = [
    { href: "#about", label: "ABOUT US" },
    { href: "#solutions", label: "PRODUCTS" },
    { href: "#technology", label: "TECHNOLOGY" },
    { href: "#news", label: "NEWS" },
    { href: "#team", label: "TEAM" },
    { href: "#careers", label: "CAREERS" },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 bg-black/90 backdrop-blur-xl border-b border-white/10">
      <div className="container mx-auto px-8 h-20 flex items-center justify-between">
        <div className="flex items-center space-x-3 z-50">
          <img 
            src={neurobusLogo} 
            alt="Neurobus Logo" 
            className="h-10 w-auto brightness-0 invert hover:scale-105 transition-transform duration-300"
          />
        </div>
        
        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center space-x-12 text-sm tracking-wide">
          {navigationItems.map((item) => (
            <a 
              key={item.href}
              href={item.href} 
              className="text-gray-300 hover:text-white transition-all duration-300 font-light relative group"
            >
              {item.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>
        
        {/* Desktop Actions */}
        <div className="hidden lg:flex items-center space-x-4">
          <Button 
            variant="ghost" 
            size="sm"
            className="text-gray-300 hover:text-white hover:bg-white/10 p-2 transition-all duration-300 hover-lift"
            asChild
          >
            <a 
              href="https://www.linkedin.com/company/neurobus/" 
              target="_blank" 
              rel="noopener noreferrer"
              aria-label="Follow Neurobus on LinkedIn"
            >
              <Linkedin className="h-4 w-4" />
            </a>
          </Button>
          
          <Button 
            variant="hero" 
            size="sm"
            className="font-light tracking-wide px-6"
            asChild
          >
            <a href="https://calendly.com/florian-neurobus/30min" target="_blank" rel="noopener noreferrer">
              SCHEDULE MEETING
            </a>
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          className="lg:hidden text-white hover:bg-white/10 p-2 z-50"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>

        {/* Mobile Menu */}
        <div className={`lg:hidden fixed inset-0 bg-black/95 backdrop-blur-xl transition-all duration-500 ${
          isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}>
          <div className="flex flex-col items-center justify-center h-full space-y-8">
            {navigationItems.map((item, index) => (
              <a 
                key={item.href}
                href={item.href} 
                className={`text-white text-2xl font-light tracking-wider hover:text-accent transition-all duration-300 ${
                  isOpen ? 'animate-fade-in' : ''
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </a>
            ))}
            
            <div className="flex flex-col items-center space-y-6 pt-8">
              <Button 
                variant="ghost" 
                size="lg"
                className="text-white hover:text-accent hover:bg-white/10 transition-all duration-300"
                asChild
              >
                <a 
                  href="https://www.linkedin.com/company/neurobus/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  aria-label="Follow Neurobus on LinkedIn"
                >
                  <Linkedin className="h-6 w-6 mr-3" />
                  LINKEDIN
                </a>
              </Button>
              
              <Button 
                variant="hero" 
                size="lg"
                className="font-light tracking-wide px-8"
                asChild
                onClick={() => setIsOpen(false)}
              >
                <a href="https://calendly.com/florian-neurobus/30min" target="_blank" rel="noopener noreferrer">
                  SCHEDULE MEETING
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;